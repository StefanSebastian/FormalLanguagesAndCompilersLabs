package app;

/**
 * Created by Sebi on 04-Nov-17.
 */
public class Constants {
    public static final String epsilon = "ε";
}
